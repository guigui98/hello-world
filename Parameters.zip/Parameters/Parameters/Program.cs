﻿using System;

namespace Parameters
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Console.WriteLine ("Function : Swap");
			int a = 6;
			int b = 3;
		    Swap (ref a,ref  b);
			Console.WriteLine (a);
			Console.WriteLine (b);
			Console.WriteLine ("Function : Div");
			a = 6;
			b = 3;
			Console.WriteLine (Div (ref a, 2));
			Console.WriteLine ("Function : Mod");
			a = 6;
			b = 3;
			Console.WriteLine (Mod (ref a, 2));
			Console.WriteLine ("Function : Sum");
			int[] arr = { 1, 2, 3, 4, 5 };
			Console.WriteLine (Sum (arr));
		}
		static void Swap (ref int a,ref int b ) {
			int c = a;
			a = b;
			b = c;
		}
		static int Div (ref int a, int b) {
			if (b <= 0 || b > a) {
				return -1;
			}
			int c = a % b;
			a = a / b;
			return c;
		}
		static bool Mod (ref int a, int b) {
			if (b <=0 || b > a) {
				return false;
			}
			a = a % b;
			return true;
		}
		static int Sum (params int[] arr) {
			int a = 0;
			if (arr.Length < 0) {
				return 0;
			}
			for (int i = 0; i < arr.Length; i++) {
				a = a + arr [i];
			}
			return a;
		}
	}
}
