﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThinkAndPlay
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> echiquierTest = new List<string>();
           
            int i = 0;
            while (i < 16)
            {
                echiquierTest.Add("Noir");
                i++;
            }
            i = 0;
            while (i < 24)
            {
                echiquierTest.Add("");

            }
            i = 0;
            while (i < 16)
            {
                echiquierTest.Add("Blanc");
                i++;
            }
           
            
           

        }
        static void IA(List<string> echiquierTest, int profondeur)
        {
            int meilleurcoup = -10;
            int max = -100000;
            for (int i = 0; i < echiquierTest.Count; i++)//Pour tout les coups possible
            {
                string stock2 = echiquierTest[i + 7];
                string stock = echiquierTest[i];
                if (echiquierTest[i] ==""|| echiquierTest[i]=="Noir") //
                {                             //Simuler un coup
                    echiquierTest[i] = "Blanc";               //
                }
                int valeuria = Min(echiquierTest, profondeur - 1);
                if (valeuria > max)
                {
                    max = valeuria;
                    meilleurcoup = i;
                }

                echiquierTest[i] = stock;//annuler le coup
                echiquierTest[i + 7] = stock2;
            }

            echiquierTest[meilleurcoup] = "Blanc";
        }
        static int Min(List<string> echiquierTest, int profondeur)
        {
            if (profondeur == 0 || fin(echiquierTest) != 0)
            {
                return eval(echiquierTest);
            }
            int min = 100000;
            for (int j = 0;j < echiquierTest.Count; j++) //Pour tout les coups possible
            {
                string stock = echiquierTest[j];
                string stock2 = echiquierTest[j+7];
                if (echiquierTest[j] == "" || echiquierTest[j] =="Noir" ) //
                {                             //Simuler un coup
                    echiquierTest[j] = "Blanc";
                    echiquierTest[j+7] = "";

                    int valeurmi = Max(echiquierTest, profondeur - 1);
                    if (valeurmi < min)
                    {
                        min = valeurmi;
                    }
                    echiquierTest[j] = stock;//annuler le coup
                    echiquierTest[j + 7] = stock2;
                    
                }
            }
            return min;
        }
        static int Max(List<string> echiquierTest, int profondeur)
        {
            if (profondeur == 0 || fin(echiquierTest) != 0)
            {
                return eval(echiquierTest);
            }
            int min = -100000;
            for (int k = 0; k < echiquierTest.Count; k++) //Pour tout les coups possible
            {
                string stock = echiquierTest[k];
                string stock2 = echiquierTest[k + 7];
                if (echiquierTest[k] == "" || echiquierTest[k] =="Blanc" ) //
                {                             //Simuler un coup
                    echiquierTest[k] = "Noir";
                    echiquierTest[k - 7] = "";
                    int valeurmi = Max(echiquierTest, profondeur - 1);
                    if (valeurmi < min)
                    {
                        min = valeurmi;
                    }
                    echiquierTest[j] = stock;//annuler le coup
                    echiquierTest[k - 7] = stock2;
                }
            }
            return min;
        }
        static int eval(List<string> echiquierTest)
        {
            int Scoreblanc=0;
            int Scorenoir=0;
            foreach (string piece in echiquierTest)
            {
                if (piece == "Blanc")
                {
                    Scoreblanc += 1;
                }
                if (piece == "Noir")
                {
                    Scorenoir += 1;
                }
            }
            return Scoreblanc - Scorenoir;
        }





    }


    }

}
               
        }

                


            }
        }
    }
}
    }
}

       
